v1=float(input("Digite o primeiro valor: "))
v2= float(input("Digite valor 2: "))
calculo=str(input("Digite a operação(+,-,*,/): "))
if calculo=="+":
    print("Resultado: ",v1+v2)
elif calculo=="-":
    print("Resultado: ",v1-v2)
elif calculo=="/":
    print("Resulto: ",v1/v2)
elif calculo=="*":
    print("Resultado: ",v1*v2)
else:
    print("Calculo não encontrado")