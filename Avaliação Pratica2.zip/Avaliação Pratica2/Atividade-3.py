v1=float(input("Valor 1: "))
v2=float(input("Valor 2: "))
v3=float(input("Valor 2: "))
if v1>v2>v3:
    print("O maior valor é valor 1: ",v1)
elif v1<v2>v3:
    print("O maior valor é valor 2: ",v2)
if v1<v2<v3:
    print("O maior valor é valor 3: ",v3)