v1=int(input("Digite o priemiro valor: "))
v2=int(input("Digite o segundo valor: "))
if v1>v2:
    print("1-",v2)
    print("2-",v1)
else:
    print("1-",v1)
    print("2-",v2)
