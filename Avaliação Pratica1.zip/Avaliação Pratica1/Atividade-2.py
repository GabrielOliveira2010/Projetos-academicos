#Atividade do calculo da agua
Massa=float(input("Didite sua massa:"))
print(f"Litros de agua com a massa de {Massa:.0f} kg é = {Massa*0.03:.0f}L")