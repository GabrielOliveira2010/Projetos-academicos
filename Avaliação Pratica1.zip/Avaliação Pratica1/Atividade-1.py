#Atividade 1- Valor do volume de uma esfera.
Valor_Raio=float(input("Valor do raio:"))
Valor_PI=float(input("Valor de pi:"))
print(f"Volme da esfera com raio {Valor_Raio} e pi {Valor_PI} é = {(4*Valor_PI*(Valor_Raio**3))/3:.1f}")
