Genero=str(input("Qual é seu genero?(Homem/Mulher): "))
Altura=float(input("Qual é sea altura em metros? "))
if Genero== "Homem":
    print("O peso ideal é",(72.7 * Altura) - 58)
else:
    print("O peso ideal é",(62.1 * Altura) - 44.7)