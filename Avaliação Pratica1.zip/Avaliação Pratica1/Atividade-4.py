Valor1=float(input("Digite o primeiro valor:"))
Valor2=float(input("digite o segundo valor:"))
if Valor1>Valor2:
    print("1-",Valor1)
    print("2-",Valor2)
else:
    print("1-",Valor2)
    print("2-",Valor1)